function ImageTool() {
    this.icon = "assets/addimage.png"; 
    this.name = "imageTool";
    var uploadedImage = null; 
    var imgSize = 100; 

    
    this.draw = function () {
        if (uploadedImage && mouseIsPressed && frameCount % 10 === 0) {
            image(uploadedImage, mouseX - imgSize / 2, mouseY - imgSize / 2, imgSize, imgSize);
        }
    };

    // Method for options of uploading and resizing the image
    this.populateOptions = function () {
        select(".options").html(
            `<div>
                <label for='imageUpload'>Upload an image:</label>
                <input type='file' id='imageUpload'><br>
                <label for='imageSize'>Resize image:</label>
                <input type='range' id='imageSize' min='50' max='300' value='100'>
             </div>`
        );

        // Had help from A senior on this part

        // image upload
        var imageUploadInput = select('#imageUpload');
        imageUploadInput.changed(function () {
            var file = imageUploadInput.elt.files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    uploadedImage = loadImage(e.target.result); // Load image from file
                };
                reader.readAsDataURL(file); // Convert the image to a data URL
            }
        });

       

        // image resizing
        var imageSizeSlider = select('#imageSize');
        imageSizeSlider.input(function () {
            imgSize = this.value(); // Update image size when slider changes
        });
    };

     // END

    // Clear options when the tool is unselected
    this.unselectTool = function () {
        select(".options").html(""); 
    };
}
