this.preload = function () {
     heavyDumbbell = loadImage('./assets/dumbbell1.png'); // Heavy dumbbell
     lightDumbbell = loadImage('./assets/dumbbell2.png'); // Light dumbbell
}

function dumbbellStampTool() {
    this.icon = "./assets/dumbbell1.png";
    this.name = "dumbbell";

 
    
   
    this.draw = function () {
            // select dumbbell type
            var selectedType = select('#dumbbellType').value();
    
            // Choose the desired dumbbell image and size
            var dumbbellImage;
            var dumbbellWeight;
            if (selectedType === "light") {
                dumbbellImage = lightDumbbell;
                dumbbellWeight = 5; // Example size for light dumbbell
            } else if (selectedType === "heavy") {
                dumbbellImage = heavyDumbbell;
                dumbbellWeight = 10; // Example size for heavy dumbbell
            }
        var dumbbellSize = select('#sizeOfdumbbells').value();
        var ndumbbells = select('#numberOfdumbbells').value();

          // Check if the mouse is pressed and if the current frame count is divisible by 5 (every 5th frame).
          //this framecount ensures that stamps is slow
        if (mouseIsPressed && frameCount % 5 === 0) {
            for (var i = 0; i < ndumbbells; i++) {
                var dumbbellX = random((mouseX - dumbbellSize / 2) - 10, (mouseX - dumbbellSize / 2) + 10);
                var dumbbellY = random((mouseY - dumbbellSize / 2) - 10, (mouseY - dumbbellSize / 2) + 10);
                image(dumbbellImage, dumbbellX, dumbbellY, dumbbellSize, dumbbellSize);
            }
        }
    }

    this.populateOptions = function () {
        select(".options").html(
            "<div> Number of dumbbells: </div>" +
            "<input type='range' id='numberOfdumbbells' name='NumberOfdumbbells' min='1' max='20' value='10'>" +
            "<div> Size of dumbbells: </div>" +
            "<input type='range' id='sizeOfdumbbells' name='SizeOfdumbbells' min='10' max='200' value='50'>" +
            "<div> Select Dumbbell Type: </div>" +
            "<select id='dumbbellType'>" +
            "<option value='light'>Light Dumbbell</option>" +
            "<option value='heavy'>Heavy Dumbbell</option>" +
            "</select>"

           
        );

    
    
    }

    this.unselectTool = function () {
        select(".options").html("");


    }

}
