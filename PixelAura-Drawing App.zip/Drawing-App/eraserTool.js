function eraserTool() {
    this.name = "eraser";
    this.icon = "assets/eraser.png";

    // i wrote this code  
    var lastMouseX = -1;
    var lastMouseY = -1;

    this.draw = function () {
        if (mouseIsPressed) {
            push();
            stroke(255, 255, 255);

            let sizeInput = select('#eraserSize');
            let eraserSize = sizeInput.value();
            strokeWeight(eraserSize);

            if (lastMouseX === -1) {
                lastMouseX = mouseX;
                lastMouseY = mouseY;
            }
            else {
                line(lastMouseX, lastMouseY, mouseX, mouseY);
                lastMouseX = mouseX;
                lastMouseY = mouseY;
            }

            pop();
        } else {
            lastMouseX = -1;
            lastMouseY = -1;
        }
    };

    // End

    this.populateOptions = function () {
        select(".options").html(
            "<div>Eraser Size:</div><input type='Range' id='eraserSize' name='number' min='1' max='200' value='10'>"
        );
    };

    this.unselectTool = function () {
        select(".options").html("");
    };
}
