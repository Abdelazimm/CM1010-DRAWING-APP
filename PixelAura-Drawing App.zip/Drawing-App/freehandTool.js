function FreehandTool() {
    this.icon = "assets/pencil.png";
    this.name = "freehand";

    var previousMouseX = -1;
    var previousMouseY = -1;

    //i wrote this code
    var strokeWeightSlider;
 
    this.draw = function () {
      
        if (mouseIsPressed) {
            
            var weight = strokeWeightSlider.value();
            strokeWeight(weight);

            if (previousMouseX == -1) {
                previousMouseX = mouseX;
                previousMouseY = mouseY;
            }
         
            else {
                line(previousMouseX, previousMouseY, mouseX, mouseY);
                previousMouseX = mouseX;
                previousMouseY = mouseY;
            }
        }
        else {
            previousMouseX = -1;
            previousMouseY = -1;
        }
    };

    //END

    // Populate the options for the tool (opacity and stroke weight sliders)
    this.populateOptions = function () {
        select(".options").html(

            "<div>pencil size: <input type='range' id='strokeWeightSlider' min='1' max='50' value='10'></div>"
           
        );
    
        strokeWeightSlider = select('#strokeWeightSlider');
    };

    // Clear the options when the tool is unselected
    this.unselectTool = function () {
        select(".options").html("");
    };

}
