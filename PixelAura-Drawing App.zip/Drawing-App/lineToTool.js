function LineToTool() {
	this.icon = "assets/line.png";
	this.name = "LineTo";

	var startMouseX = -1;
	var startMouseY = -1;
	var drawing = false;
	var strokeWeightSlider;

	this.draw = function () {

		if (mouseIsPressed) {
			//i wrote this code
			var weight = strokeWeightSlider.value();

			strokeWeight(weight);

			//end

			if (startMouseX == -1) {
				startMouseX = mouseX;
				startMouseY = mouseY;
				drawing = true;
				loadPixels();
			}

			else {
				updatePixels();
				line(startMouseX, startMouseY, mouseX, mouseY);
			}

		}

		else if (drawing) {
			drawing = false;
			startMouseX = -1;
			startMouseY = -1;
		}
	};

	// Populate the options for the tool (opacity and stroke weight sliders)
	this.populateOptions = function () {
		select(".options").html(

			"<div>Stroke Weight: <input type='range' id='strokeWeightSlider' min='1' max='50' value='10'></div>"
		);

		strokeWeightSlider = select('#strokeWeightSlider');
	};

	// Clear the options when the tool is unselected
	this.unselectTool = function () {
		select(".options").html("");
	};

}
