
function sprayTool() {
    this.name = "sprayTool"
    this.icon = "assets/spray3.png"
    this.points = 30
    this.spread = 30

    this.draw = function () {
        //if the mouse is pressed paint on the canvas
        //spread describes how far to spread the paint from the mouse pointer
        //points holds how many pixels of paint for each mouse press.
        if (mouseIsPressed) {
            for (var i = 0; i < this.points; i++) {
                point(random(mouseX - this.spread, mouseX + this.spread),
                    random(mouseY - this.spread, mouseY + this.spread));
            }
        }
    }

        this.populateOptions = function () {
            select(".options").html(
                "<div>Spread: <input type='range' id='spreadSlider' min='10' max='100' value='" + this.spread + "'></div>"
            );
    
          // slider to control spread
            var spreadSlider = select("#spreadSlider");
            spreadSlider.input(() => {
                this.spread = spreadSlider.value();
            });
        };
    
        this.unselectTool = function () {
            select(".options").html("");
        };


};