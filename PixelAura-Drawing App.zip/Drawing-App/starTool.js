this.preload = function () {
    starImage = loadImage('assets/star.png');
}

function starTool() {
    this.icon = "assets/star.png";
    this.name = "star";

    var starImage = loadImage("assets/star.png");

    var sizeOfStarSlider 
    var numberOfStarsSlider 


    this.draw = function () {
        if (mouseIsPressed && frameCount % 5 === 0) {
            for (var i = 0; i < numberOfStarsSlider.value(); i++) {
                var sizeOfStar = sizeOfStarSlider.value();
                var xOffset = random(-10, 20);
                var yOffset = random(-10, 20);
                var starX = mouseX - sizeOfStar / 2 + xOffset;
                var starY = mouseY - sizeOfStar / 2 + yOffset;
                image(starImage, starX, starY, sizeOfStar, sizeOfStar);
            }
        }
    }

    this.populateOptions = function () {
        select(".options").html(
            "<div> Number of Stars: </div>" +
            "<div id='numberOfStarsSlider'></div>" +
            "<div> Size of Stars: </div>" +
            "<div id='sizeOfStarSlider'></div>"
        );

        numberOfStarsSlider = createSlider(1, 20, 5);
        numberOfStarsSlider.parent('numberOfStarsSlider');

        sizeOfStarSlider = createSlider(5, 70, 20);
        sizeOfStarSlider.parent('sizeOfStarSlider');
    }

    this.unselectTool = function () {
        select(".options").html("");
    }
}
