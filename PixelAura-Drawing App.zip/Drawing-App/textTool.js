function TextTool() {
    this.icon = "assets/text.png";
    this.name = "Text";

    // text input and drawing variables
    var textInput = "";
    this.selectedColour = "black"; 
    var textSizeValue = 30; 
    var textAlignValue = LEFT; 
    var fontStyle = "Arial"; 

  
    this.draw = function () {
        if (mouseIsPressed && textInput !== "" && frameCount % 5 === 0) {
            noStroke();
            fill(this.selectedColour); 
            textSize(textSizeValue); 
            textFont(fontStyle);
            textAlign(textAlignValue); 
            text(textInput, mouseX, mouseY); 
        }
    };

 
    this.populateOptions = function () {
        select(".options").html(
            `<div>
                Type text here: <input type='text' id='textInput' name='text'>
                <br><br>
                Text size: <input type='range' id='textSizeSlider' min='10' max='100' value='${textSizeValue}'>
                <br><br>
                Text color: <input type='color' id='textColor' value='${this.selectedColour}'>
                <br><br>
                Font style:
                <select id='fontStyle'>
                    <option value='Arial'>Arial</option>
                    <option value='Georgia'>Georgia</option>
                    <option value='Courier New'>Courier New</option>
                    <option value='Times New Roman'>Times New Roman</option>
                    <option value='Verdana'>Verdana</option>
                </select>
                
            </div>`
        );

        // Event listener for text input
        var textInputField = select('#textInput');
        textInputField.input(function () {
            textInput = this.value();
        });

        // Event listener for text size slider
        var textSizeSlider = select('#textSizeSlider');
        textSizeSlider.input(function () {
            textSizeValue = this.value();
        });

        // Event listener for text color
        var textColorPicker = select('#textColor');
        textColorPicker.input(() => {
            this.selectedColour = textColorPicker.value();
        });

        // Event listener for font style
        var fontStyleSelect = select('#fontStyle');
        fontStyleSelect.changed(() => {
            fontStyle = fontStyleSelect.value();
        });

       
    };

    
    this.unselectTool = function () {
        textInput = "";
        select(".options").html(""); 
    };

    // Method to update the selected color from the color palette
    this.setColour = function (colour) {
        this.selectedColour = colour; 
    };
}
