function triangleTool() {
    
    this.icon = "assets/triangle.png";
    this.name = "Triangle";

    // I wrote this code
   
    var startMouseX = -1;
    var startMouseY = -1;
    var drawing = false;

    // Method to draw triangle
    this.draw = function () {
       
        if (mouseIsPressed) {
          
            if (startMouseX == -1) {
                startMouseX = mouseX;
                startMouseY = mouseY;
                drawing = true;
                loadPixels();
            } else {
            
                updatePixels();
                noFill();
                // Retrieve stroke weight from UI element
                var selectItem = select('#strokeWeight');
                var w = selectItem.value();
                strokeWeight(w);
                triangle(startMouseX, startMouseY, mouseX, mouseY, startMouseX + (mouseX - startMouseX), startMouseY);
            }
        } else if (drawing) {
            drawing = false;
            startMouseX = -1;
            startMouseY = -1;
        }
    };

    // End

   
    this.populateOptions = function () {
        select(".options").html(
            "<div> Triangle stroke size: </div><input type='range' id='strokeWeight' name='range' 'min=1' 'max=30' value='10'>"
        );
    };

    // Method to clear options when tool is unselected
    this.unselectTool = function () {
        select(".options").html("");
    };
}
